<div class="qodef-single-tags-holder">
	<h6 class="qodef-single-tags-title"><?php esc_html_e('Tags:', 'startit'); ?></h6>
	<div class="qodef-tags">
		<?php the_tags('', ',', ''); ?>
	</div>
</div>