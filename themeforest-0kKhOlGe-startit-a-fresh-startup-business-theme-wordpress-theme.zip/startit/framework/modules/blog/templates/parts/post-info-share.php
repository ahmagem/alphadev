<div class="qodef-blog-share">
	<?php if ( startit_qode_is_plugin_installed( 'core' ) ) {
		echo qode_startit_get_social_share_html();
	} ?>
</div>