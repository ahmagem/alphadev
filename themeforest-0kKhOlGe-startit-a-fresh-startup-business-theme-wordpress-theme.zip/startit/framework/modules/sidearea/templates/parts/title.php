<div class="qodef-side-menu-title">
	<h5><?php echo esc_html($side_area_title) ?></h5>
</div>